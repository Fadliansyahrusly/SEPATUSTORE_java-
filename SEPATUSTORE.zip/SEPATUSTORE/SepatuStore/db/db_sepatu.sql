-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2018 at 08:11 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sepatu`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `laporan`
-- (See below for the actual view)
--
CREATE TABLE `laporan` (
`totalseluruh` int(11)
,`bayar` int(11)
,`kembali` int(11)
,`id_transaksi` varchar(15)
,`id_sepatu` varchar(15)
,`jenis` varchar(100)
,`merek` varchar(100)
,`harga` int(100)
,`jumlah` int(60)
,`subtotal` int(40)
);

-- --------------------------------------------------------

--
-- Table structure for table `tb_sepatu`
--

CREATE TABLE `tb_sepatu` (
  `id_sepatu` varchar(15) NOT NULL,
  `jenis` varchar(80) NOT NULL,
  `merk` varchar(80) NOT NULL,
  `harga` int(80) NOT NULL,
  `stok` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_sepatu`
--

INSERT INTO `tb_sepatu` (`id_sepatu`, `jenis`, `merk`, `harga`, `stok`) VALUES
('S00001', 'BOTS', 'Astra', 90000, 8948),
('S00003', 'Sepatu Kets', 'Adidas', 100000, 64),
('S00004', 'Docmart', 'Air Ways', 350000, 73),
('S00005', 'Running', 'Addidas', 200000, -2),
('S00006', 'ballet', 'balerina', 250000, 50),
('S00007', 'olahraga', 'nike', 150000, 500);

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id_transaksi` varchar(15) NOT NULL,
  `id_sepatu` varchar(15) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `merek` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `jumlah` int(60) NOT NULL,
  `subtotal` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id_transaksi`, `id_sepatu`, `jenis`, `merek`, `harga`, `jumlah`, `subtotal`) VALUES
('T00001', 'S00003', 'Sepatu Kets', 'Adidas', 100000, 2, 200000),
('T00001', 'S00005', 'Running', 'Addidas', 200000, 2, 400000),
('T00001', 'S00003', 'Sepatu Kets', 'Adidas', 100000, 1, 100000);

--
-- Triggers `tb_transaksi`
--
DELIMITER $$
CREATE TRIGGER `stok_kurang` AFTER INSERT ON `tb_transaksi` FOR EACH ROW BEGIN
UPDATE tb_sepatu SET stok = stok - new.jumlah WHERE 
tb_sepatu.id_sepatu = new.id_sepatu;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_uang`
--

CREATE TABLE `tb_uang` (
  `id_transaksi` varchar(15) NOT NULL,
  `totalseluruh` int(11) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembali` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_uang`
--

INSERT INTO `tb_uang` (`id_transaksi`, `totalseluruh`, `bayar`, `kembali`) VALUES
('T00001', 700000, 710000, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`) VALUES
(1, 'fadli', 'fadli');

-- --------------------------------------------------------

--
-- Structure for view `laporan`
--
DROP TABLE IF EXISTS `laporan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `laporan`  AS  select `tb_uang`.`totalseluruh` AS `totalseluruh`,`tb_uang`.`bayar` AS `bayar`,`tb_uang`.`kembali` AS `kembali`,`tb_transaksi`.`id_transaksi` AS `id_transaksi`,`tb_transaksi`.`id_sepatu` AS `id_sepatu`,`tb_transaksi`.`jenis` AS `jenis`,`tb_transaksi`.`merek` AS `merek`,`tb_transaksi`.`harga` AS `harga`,`tb_transaksi`.`jumlah` AS `jumlah`,`tb_transaksi`.`subtotal` AS `subtotal` from (`tb_transaksi` join `tb_uang` on((`tb_uang`.`id_transaksi` = `tb_transaksi`.`id_transaksi`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_sepatu`
--
ALTER TABLE `tb_sepatu`
  ADD PRIMARY KEY (`id_sepatu`);

--
-- Indexes for table `tb_uang`
--
ALTER TABLE `tb_uang`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
