/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HomeSepatu;

import java.awt.Desktop;
import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Fadliansyah Rusli
 */
public class Transaksi extends javax.swing.JFrame {
 Connection con = new Login.koneksi().getConnection();
    ResultSet rs;
    Statement st;
    PreparedStatement prst;
    String sql;
    public Home h;
    /**
     * Creates new form Transaksi
     */
    public DefaultTableModel transaksi;
        public DefaultTableModel table_keranjang;

    public Transaksi() {
        initComponents();
        autokode();
        idtr.setEditable(false);
        total.setEditable(false);
        kembali.setEditable(false);
        tampil_table();
        tampil_table1();

    }
    
    
    public void autokode(){
        try {
            sql = "SELECT * FROM tb_transaksi ORDER BY id_transaksi DESC";
            prst = con.prepareStatement(sql);
            rs = prst.executeQuery();
            if (rs.next()) {
                String kode_otomatis = rs.getString("id_transaksi").substring(1);
                String an = ""+(Integer.parseInt(kode_otomatis)+1);
                String nol = "";
                if (an.length() == 1) {
                    nol = "0000";
                }else if(an.length() == 2){
                    nol = "000";
                }else if(an.length() == 3){
                    nol = "00";
                }else if(an.length() == 4){
                    nol = "0";
                }else if(an.length() == 5){
                    nol = "";
                }
                idtr.setText("T"+nol+an);
            }else{
                idtr.setText("T00001");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void table(){
        for(int a=0; a < tb_transaksi.getColumnCount(); a++){
            Class <?> b = tb_transaksi.getColumnClass(a);
            tb_transaksi.setDefaultEditor(b, null);
        }
    }
    public void tampil_table(){
        Object[]tampil_table = {"ID Sepatu","Jenis Sepatu","Merk Sepatu","Harga Sepatu","Stok Sepatu"};
        transaksi = new DefaultTableModel(null, tampil_table);
        tb_transaksi.setModel(transaksi);
    }
     public void tampil_data(){
        try{
            st = con.createStatement();
            transaksi.getDataVector().removeAllElements();
            transaksi.fireTableDataChanged();
            rs = st.executeQuery("SELECT * FROM tb_sepatu");
            while(rs.next()){
                Object[]data={
                    rs.getString("id_sepatu"),
                    rs.getString("jenis"),
                    rs.getString("merk"),
                    rs.getString("harga"),
                    rs.getString("stok"),
                };
                transaksi.addRow(data);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
     public void table1(){
        for(int a=0; a < tb_keranjang.getColumnCount(); a++){
            Class <?> b = tb_keranjang.getColumnClass(a);
            tb_keranjang.setDefaultEditor(b, null);
        }
    }
    
    public void tampil_table1(){
        Object[]tampil_table = {"ID Transaksi","ID Sepatu","Jenis","Merek","Harga","Jumlah Beli","Sub Total"};
        table_keranjang = new DefaultTableModel(null, tampil_table);
        tb_keranjang.setModel(table_keranjang);
    }
     public void tampil_keranjang(){
        try{
            st = con.createStatement();
            table_keranjang.getDataVector().removeAllElements();
            table_keranjang.fireTableDataChanged();
            rs = st.executeQuery("SELECT * FROM tb_transaksi where id_transaksi='"+idtr.getText()+"'");
            while(rs.next()){
                Object[]data = {
                    rs.getString("id_transaksi"),
                    rs.getString("id_sepatu"),
                    rs.getString("jenis"),
                    rs.getString("merek"),
                    rs.getString("harga"),
                    rs.getString("jumlah"),
                    rs.getString("subtotal"),

                };
                table_keranjang.addRow(data);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
     public void edit(){
            try {
                int bar = tb_transaksi.getSelectedRow();
                String a = tb_transaksi.getValueAt(bar, 0).toString();
                String b = tb_transaksi.getValueAt(bar, 1).toString();
                String c = tb_transaksi.getValueAt(bar, 2).toString();
                String d = tb_transaksi.getValueAt(bar, 3).toString();
                String e = tb_transaksi.getValueAt(bar, 4).toString();
                
                id.setText(a);
                jenis.setText(b);
                merek.setText(c);
                harga.setText(d);
                stok.setText(e);
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
     public void reset(){
        id.setText("");
        jenis.setText("");
        merek.setText("");
        harga.setText("");
        jumbel.setText("");
        total.setText("");
    }
        public void simpan(){
        if (id.getText().equals("") || jenis.getText().equals("") || merek.getText().equals("") || harga.getText().equals("") 
                || jumbel.getText().equals("")||total.getText().equals(""
                        + "") ) {
            JOptionPane.showMessageDialog(null, "Harap Lengkapi Data!");
        }else{
            try {
                st = con.createStatement();
                st.executeUpdate("INSERT INTO tb_transaksi SET id_transaksi='" + idtr.getText() + "', id_sepatu='" + id.getText() + "'," + "jenis='" + jenis.getText() +"', merek='" + merek.getText() + "', harga='" + harga.getText() + "', jumlah='" + jumbel.getText() + "', subtotal='" + total.getText() + "'");
                JOptionPane.showMessageDialog(null, "Data Tersimpan","Informasi", JOptionPane.INFORMATION_MESSAGE);
                reset();
                tampil_data();
                tampil_keranjang();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
        public void harga_keseluruhan(){
        try{
            sql = ("SELECT SUM(subtotal) as hargasel FROM tb_transaksi");
            st = con.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                totalseluruh.setText(rs.getString("hargasel"));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
        public void cetakstruk(){
                 if (Desktop.isDesktopSupported()) {
            try{
                Desktop.getDesktop().browse(new URI ("http://localhost:81/laporan/struk.php"));
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        stok = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        idtr = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        jenis = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        merek = new javax.swing.JTextField();
        harga = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jumbel = new javax.swing.JTextField();
        total = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_transaksi = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tb_keranjang = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        totalseluruh = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        bayar = new javax.swing.JTextField();
        kembali = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        update = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(stok, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 170, -1, -1));

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/icons8_Home_50px.png"))); // NOI18N
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 30, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/icons8_Boots_52px.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, -1, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/icons8_Trainers_50px.png"))); // NOI18N
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/icons8_Ballet_Shoes_52px_2.png"))); // NOI18N
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        jLabel17.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 102, 102));
        jLabel17.setText("TRANSAKSI");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 40, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 930, 130));

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID Transaksi");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, -1, -1));
        jPanel2.add(idtr, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 170, 30));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID Sepatu");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, -1, -1));
        jPanel2.add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 90, 170, 30));
        jPanel2.add(jenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 170, 30));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Jenis");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, 20));

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Merek");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 60, 20));
        jPanel2.add(merek, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 170, 30));
        jPanel2.add(harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 240, 170, 30));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Harga Satuan");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, -1, -1));

        jLabel7.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Jumlah Beli");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, -1, 20));

        jumbel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jumbelKeyReleased(evt);
            }
        });
        jPanel2.add(jumbel, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, 170, 30));

        total.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        jPanel2.add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 340, 170, 30));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Sub Total");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, -1, 10));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setText("Beli Barang");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, -1, 33));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 153, 153));
        jLabel9.setText("Daftar Sepatu");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 50, -1, -1));

        tb_transaksi.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        tb_transaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID Sepatu", "Jenis Sepatu", "Merek", "Harga Sepatu", "Stok Sepatu"
            }
        ));
        tb_transaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_transaksiMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tb_transaksiMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(tb_transaksi);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 80, -1, 100));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(153, 153, 153));
        jLabel8.setText("Keranjang");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 200, -1, -1));

        tb_keranjang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Transaksi", "ID Sepatu", "Jenis", "Merek", "Harga", "Jumlah", "Sub Total"
            }
        ));
        tb_keranjang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_keranjangMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tb_keranjang);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 250, 510, 100));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton2.setText("Masukkan Keranjang");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 390, 160, 33));

        jLabel11.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Total Keseluruhan");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 440, -1, -1));

        totalseluruh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalseluruhActionPerformed(evt);
            }
        });
        jPanel2.add(totalseluruh, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 470, 240, 30));

        jLabel12.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Bayar");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 440, -1, -1));

        bayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                bayarKeyReleased(evt);
            }
        });
        jPanel2.add(bayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 470, 240, 30));
        jPanel2.add(kembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 470, 240, 30));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Kemabalian");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 440, -1, -1));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton3.setText("Selesai Transaksi");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 540, -1, 40));

        update.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        jPanel2.add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 390, 80, 30));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 930, 660));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        // TODO add your handling code here:
        h = new Home();
        h.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel13MouseClicked

    private void jumbelKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jumbelKeyReleased
        // TODO add your handling code here:
        if (jumbel.getText().toString().equals("")) {
            jumbel.setText("");
            total.setText("0");
        }else{
            long n1, n2, jumlah;
            String d;
            n1 = Long.valueOf(harga.getText());
            n2 = Long.valueOf(jumbel.getText());
            jumlah = n1 * n2;
            d = String.valueOf(jumlah);
            total.setText(d);

            int a    = Integer.parseInt(jumbel.getText());
            int b    = Integer.parseInt(harga.getText());
            jumlah = a * b;
            total.setText(String.valueOf(jumlah));
        }
    }//GEN-LAST:event_jumbelKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        tampil_data();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tb_transaksiMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_transaksiMousePressed
        // TODO add your handling code here:
        edit();
    }//GEN-LAST:event_tb_transaksiMousePressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        simpan();
        harga_keseluruhan();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void totalseluruhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalseluruhActionPerformed
        // TODO add your handling code here:
        harga_keseluruhan();
    }//GEN-LAST:event_totalseluruhActionPerformed

    private void bayarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bayarKeyReleased
        // TODO add your handling code here:
        long a = Long.valueOf(totalseluruh.getText());
        long b = Long.valueOf(bayar.getText());
        long e;
        String d;
        e = b-a;
        d = Long.toString(e);
        kembali.setText(d);
    }//GEN-LAST:event_bayarKeyReleased

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        if (bayar.getText().equals("") ) {
            JOptionPane.showMessageDialog(null, "Bayar Dulu!");
        }else{
            long a,b;
            a = Long.valueOf(totalseluruh.getText());
            b = Long.valueOf(bayar.getText());
            if (b < a){
                JOptionPane.showMessageDialog(null, "Uang Anda Kurang");
            }else{
            try {
                st = con.createStatement();
                st.executeUpdate("INSERT INTO tb_uang SET id_transaksi='" + idtr.getText() + "', totalseluruh='" + totalseluruh.getText() + "'," + "bayar='" + bayar.getText() +"', kembali='" + kembali.getText() + "'");
                JOptionPane.showMessageDialog(null, "Data Tersimpan","Informasi", JOptionPane.INFORMATION_MESSAGE);
                autokode();
                reset();
                tampil_data();
                tampil_keranjang();
                cetakstruk();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void tb_keranjangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_keranjangMouseClicked
        try {
                int bar = tb_keranjang.getSelectedRow();
                String a = tb_keranjang.getValueAt(bar, 1).toString();
                String b = tb_keranjang.getValueAt(bar, 2).toString();
                String c = tb_keranjang.getValueAt(bar, 3).toString();
                String d = tb_keranjang.getValueAt(bar, 4).toString();
                
                idtr.setText(tb_keranjang.getValueAt(bar, 0).toString());
                id.setText(a);
                jenis.setText(b);
                merek.setText(c);
                harga.setText(d);
                
                jumbel.setText(tb_keranjang.getValueAt(bar, 5).toString());
                total.setText(tb_keranjang.getValueAt(bar, 6).toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        jButton2.setEnabled(false);
    }//GEN-LAST:event_tb_keranjangMouseClicked

    private void tb_transaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_transaksiMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_tb_transaksiMouseClicked

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        try{
            st = con.createStatement();
            st.executeUpdate("UPDATE tb_transaksi SET jumlah='"+jumbel.getText()+"',subtotal='"+total.getText()+"' WHERE id_sepatu='"+id.getText()+"'");
            JOptionPane.showMessageDialog(null, "Berasil");
            tampil_keranjang();
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_updateActionPerformed
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bayar;
    private javax.swing.JTextField harga;
    private javax.swing.JTextField id;
    private javax.swing.JTextField idtr;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jenis;
    private javax.swing.JTextField jumbel;
    private javax.swing.JTextField kembali;
    private javax.swing.JTextField merek;
    private javax.swing.JLabel stok;
    private javax.swing.JTable tb_keranjang;
    private javax.swing.JTable tb_transaksi;
    private javax.swing.JTextField total;
    private javax.swing.JTextField totalseluruh;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
